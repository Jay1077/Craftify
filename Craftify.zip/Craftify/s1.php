<?php
/*if ( !isset($_SESSION['login2']))
{
	echo "<script>";
	echo 'location.replace("index.php")';
	echo "</script>";
}*/
?>